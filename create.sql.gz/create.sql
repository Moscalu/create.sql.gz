CREATE TABLE `role` (
        `roleid`                 bigint unsigned                           NOT NULL,
        `name`                   varchar(255)    DEFAULT ''                NOT NULL,
        `type`                   integer         DEFAULT '0'               NOT NULL,
        `readonly`               integer         DEFAULT '0'               NOT NULL,
        PRIMARY KEY (roleid)
) ENGINE=InnoDB;
CREATE UNIQUE INDEX `role_1` ON `role` (`name`);
CREATE TABLE `users` (
        `userid`                 bigint unsigned                           NOT NULL,
        `alias`                  varchar(100)    DEFAULT ''                NOT NULL,
        `name`                   varchar(100)    DEFAULT ''                NOT NULL,
        `surname`                varchar(100)    DEFAULT ''                NOT NULL,
        `passwd`                 varchar(60)     DEFAULT ''                NOT NULL,
        `url`                    varchar(255)    DEFAULT ''                NOT NULL,
        `autologin`              integer         DEFAULT '0'               NOT NULL,
        `autologout`             varchar(32)     DEFAULT '15m'             NOT NULL,
        `lang`                   varchar(7)      DEFAULT 'default'         NOT NULL,
        `refresh`                varchar(32)     DEFAULT '30s'             NOT NULL,
        `theme`                  varchar(128)    DEFAULT 'default'         NOT NULL,
        `attempt_failed`         integer         DEFAULT 0                 NOT NULL,
        `attempt_ip`             varchar(39)     DEFAULT ''                NOT NULL,
        `attempt_clock`          integer         DEFAULT 0                 NOT NULL,
        `rows_per_page`          integer         DEFAULT 50                NOT NULL,
        `timezone`               varchar(50)     DEFAULT 'default'         NOT NULL,
        `roleid`                 bigint unsigned                           NOT NULL,
